# Replay the Lean proofs

The formal directory contains the project's Lean sources and the Lake manifest
that pins its dependencies. Open formal/CirclePairedGDTheorem.lean for the
discrete gradient descent result and formal/CirclePairedTheorem.lean for
gradient flow. The repository-relative source paths in the paper also apply
inside this archive.

To replay the proofs, extract the entire archive. With Git, elan, and Python
3.11 or newer installed, run these commands from the extracted directory.
The first Lake invocation needs access to any pinned dependencies absent
from the local cache.

    cd formal
    lake exe cache get
    python3 verify.py --report .lake/replay

The verifier rebuilds the project, inventories the declarations and their
axioms, exports the dependencies of every safe project declaration, and replays
the export with leanchecker and leanchecker-paranoid. Compare the resulting
.lake/replay/receipt.json with verification/receipt.json. The original build
log, axiom audits, checker logs, and declaration inventory are in verification/.
